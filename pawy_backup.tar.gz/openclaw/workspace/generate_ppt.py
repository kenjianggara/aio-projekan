
from pptx import Presentation
from pptx.util import Inches, Pt

# Initialize a new presentation
prs = Presentation()

# Slide 1: Title Slide
slide_layout = prs.slide_layouts[0]
slide = prs.slides.add_slide(slide_layout)
title = slide.shapes.title
subtitle = slide.placeholders[1]
title.text = "Laporan Ringkas: Adversarial Attack Simulation Exercise (AASE)"
subtitle.text = "PT Bank Mandiri Tbk\nFebruari 2026"

# Define content slide layout
content_layout = prs.slide_layouts[1]

# Slide 2: Executive Summary
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Ringkasan Eksekutif"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Tujuan: Menguji efektivitas kontrol keamanan endpoint melalui simulasi serangan siber yang realistis."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Pelaksana: PT DSIS & Unit 42 (Palo Alto Networks)."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Hasil Utama: Kontrol keamanan (AV/XDR) efektif memblokir payload awal, namun Red Team berhasil mendapatkan akses setelah proses allow-listing. Terdapat temuan penting terkait visibilitas dan respons insiden."
p.font.size = Pt(18)

# Slide 3: Scope & Methodology
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Ruang Lingkup & Metodologi"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Sistem yang Diuji: System 1 (MDTNB599...), System 2 (MDTNB193...), System 3 (MDTNB781...)."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Skenario Serangan: Menggunakan 4 jenis payload (disguised .bat, macro Word/Excel, standalone .exe) & Social Engineering via email."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Kerangka Acuan: MITRE ATT&CK."
p.font.size = Pt(18)

# Slide 4: Findings System 1
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Temuan di System 1 - Garis Pertahanan Awal"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Payload awal (Payload 1.1 & 2.1) berhasil dideteksi dan diblokir saat ekstraksi."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Upaya evasive (instalasi VM, VSCode Remote Tunnel) juga digagalkan oleh kebijakan sistem."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Kesimpulan: Pertahanan lapis pertama (blocking) berjalan dengan baik."
p.font.bold = True
p.font.size = Pt(18)

# Slide 5: Findings System 2
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Temuan di System 2 - Kegigihan & Isolasi"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Payload 2.2 sempat menyebabkan isolasi endpoint otomatis oleh sistem keamanan."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Menunjukkan sistem deteksi (EDR) proaktif, meskipun ada kebutuhan untuk tuning (terjadi isolasi kembali)."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Setelah proses allow-listing, Payload 4.2 berhasil dijalankan dan membangun koneksi C2 yang stabil."
p.font.size = Pt(18)

# Slide 6: Findings System 3
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Temuan di System 3 - Serangan Social Engineering"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Skenario serangan via email berhasil mengirimkan payload ke target."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Pengguna berhasil mengunduh dan membuka file."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Kemenangan Blue Team: Cortex XDR berhasil mendeteksi dan memblokir macro berbahaya saat eksekusi."
p.font.bold = True
p.font.size = Pt(18)

# Slide 7: Timeline
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Linimasa Serangan (Highlights)"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Minggu 1 (12-18 Nov): Fase Inisial. Banyak payload diblokir, Red Team mencari celah via aplikasi (VSCode)."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Minggu 2 (19-25 Nov): Fase Evasif & Social Engineering. Penggunaan custom VSCode extension dan serangan email."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Minggu 3 & 4 (27 Nov - Des): Fase Persistensi. Fokus pada allow-listing dan menjalankan Payload 4.x."
p.font.size = Pt(18)

# Slide 8: Recommendations
slide = prs.slides.add_slide(content_layout)
slide.shapes.title.text = "Rekomendasi Utama"
body = slide.shapes.placeholders[1].text_frame
body.clear()
p = body.paragraphs[0]
p.text = "Perkuat Kebijakan Aplikasi: Tinjau kembali kebijakan untuk tool seperti VSCode & VirtualBox."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Tuning Aturan Deteksi: Kalibrasi aturan EDR/XDR untuk mengurangi false positive atau isolasi yang tidak perlu."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Tingkatkan Pelatihan Pengguna: Tekankan kewaspadaan dalam menangani lampiran email."
p.font.size = Pt(18)
p = body.add_paragraph()
p.text = "Review Proses Allow-listing: Pastikan proses memiliki kontrol yang ketat untuk mencegah penyalahgunaan."
p.font.size = Pt(18)

# Slide 9: Q&A
slide_layout = prs.slide_layouts[5] # Blank slide
slide = prs.slides.add_slide(slide_layout)
textbox = slide.shapes.add_textbox(Inches(1), Inches(2), Inches(8), Inches(2))
tf = textbox.text_frame
p = tf.paragraphs[0]
p.text = "Penutup & Tanya Jawab"
p.font.size = Pt(44)
p.font.bold = True

prs.save("Laporan_AASE_Bank_Mandiri.pptx")
print("Presentation generated successfully.")
