#!/bin/bash
# Script untuk mengumpulkan data monitoring harian

# Tentukan file log berdasarkan tanggal hari ini
LOG_DIR="/home/kenjian99ara/.openclaw/workspace/memory/monitoring"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/$(date +'%Y-%m-%d').md"

# Ambil data
CPU_LOAD=$(uptime | awk -F'load average: ' '{print $2}')
RAM_USAGE=$(free -h | grep Mem | awk '{print "Used: " $3 " / Total: " $2 " (" $7 " avail)"}')
DISK_USAGE=$(df -h / | grep / | awk '{print "Used: " $3 " / Total: " $2 " (" $5 " full)"}')

# Tulis ke file log (akan menimpa file jika sudah ada, untuk memastikan data selalu fresh)
echo "# Laporan Monitoring Harian - $(date +'%Y-%m-%d %H:%M WIB')" > "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "### 1. Status VM Google Cloud" >> "$LOG_FILE"
echo "**Sisa Kredit GCP:** (perlu diisi manual oleh Kenji)" >> "$LOG_FILE"
echo "**Penggunaan CPU (load avg):** $CPU_LOAD" >> "$LOG_FILE"
echo "**Penggunaan RAM:** $RAM_USAGE" >> "$LOG_FILE"
echo "**Penggunaan Disk:** $DISK_USAGE" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "### 2. Status Integrasi API" >> "$LOG_FILE"
echo "**Google Gemini (Gratis):**" >> "$LOG_FILE"
echo "- **Limit:** 60 Permintaan / Menit (RPM)." >> "$LOG_FILE"
echo "- **Status:** Batas kecepatan, bukan kuota. Aman untuk penggunaan normal." >> "$LOG_FILE"
echo "- **Token Sesi Ini:** (akan diisi oleh Pawy saat laporan dibuat)" >> "$LOG_FILE"
echo "**Brave Search (Gratis):**" >> "$LOG_FILE"
echo "- **Limit:** 2.000 Pencarian / Bulan." >> "$LOG_FILE"
echo "- **Status:** Belum pernah digunakan." >> "$LOG_FILE"

echo "Laporan monitoring berhasil dibuat di $LOG_FILE"
