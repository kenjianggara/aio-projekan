# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Kenji
- **What to call them:** Kenji
- **Pronouns:** _(optional)_
- **Timezone:** WIB (GMT+7)
- **Notes:** Based in Jakarta.

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
